vacts = (
    ('Normalize', 'Normalize', ''),
    ('Cut', 'Cut', ''),
    ('None', 'None', ''),
)