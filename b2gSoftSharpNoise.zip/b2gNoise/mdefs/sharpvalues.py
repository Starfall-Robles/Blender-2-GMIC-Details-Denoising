svals = (
    ('Normalize Luma', 'Normalize Luma', ''),
    ('Cut', 'Cut', ''),
)