bsplines = (
    ('Spline B1', 'Spline B1', ''),
    ('Spline B2', 'Spline B2', ''),
    ('Spline B3', 'Spline B3', ''),
    ('Spline B4', 'Spline B4', ''),
    ('Spline B5', 'Spline B5', ''),
    ('Spline B6', 'Spline B6', ''),
)