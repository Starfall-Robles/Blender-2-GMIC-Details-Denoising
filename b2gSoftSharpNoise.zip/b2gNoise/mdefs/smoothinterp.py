interps = (
    ('Nearest Neighbor', 'Nearest Neighbor', ''),
    ('Linear', 'Linear', ''),
    ('Runge-Kutta', 'Runge-Kutta', ''),
)