sharps = (
    ('Bilateral', 'Bilateral', ''),
    ('Gaussian', 'Gaussian', ''),
)