prevshows = (
    ('Output', 'OUTPUT', ''),
    ('Difference', 'DIFFERENCE', ''),
)