prevlist = (
    ('Full', 'Full', ''),
)