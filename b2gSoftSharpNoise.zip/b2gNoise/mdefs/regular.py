regs = (
    ('Total Variation', 'Total Variation', ''),
    ('Mean Curvature', 'Mean Curvature', ''),  
    ('Tikhonov', 'Tikhonov', ''),
)