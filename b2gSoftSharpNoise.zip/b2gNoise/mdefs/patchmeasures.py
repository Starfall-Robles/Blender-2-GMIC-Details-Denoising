patches = (
    ('RGB', 'RGB', ''),
    ('Lightness', 'Lightness', ''),
    ('Luminance', 'Luminance', ''),
    ('L2-norm', 'L2-norm', ''),
    ('L1-norm', 'L1-norm', ''),
    ('Linf-norm', 'Linf-norm', ''),
)