parallels = (
    ('Auto', 'AUTO', ''),
    ('Off', 'OFF', ''),
)