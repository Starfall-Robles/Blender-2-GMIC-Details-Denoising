fastdnp = (
    ('Normal Output', 'Normal Output', ''),
    ('Luma Noise', 'Luma Noise', ''),
    ('Chroma Noise', 'Chroma Noise', ''),
)