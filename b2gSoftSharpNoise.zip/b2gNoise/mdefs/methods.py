usemethods = (
    ('Old Method - slowest', 'Old Method - slowest', ''),
    ('Hybrid Median - medium speed softest output', 'Hybrid Median - medium speed softest output', ''),
    ('Morphological - fastest sharpest output', 'Morphological - fastest sharpest output', ''),
)