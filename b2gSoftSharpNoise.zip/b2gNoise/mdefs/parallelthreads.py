pthreads= (
    ('Auto', 'Auto', ''),
    ('One Thread', 'One Thread', ''),
    ('Two Threads', 'Two Threads', ''),
    ('Four Threads', 'Four Threads', ''),
    ('Eight Threads', 'Eight Threads', ''),
    ('Sixteen Threads', 'Sixteen Threads', ''),
)